#!/bin/bash
docker-compose up -d 